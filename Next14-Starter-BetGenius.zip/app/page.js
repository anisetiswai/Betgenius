export default function HomePage() {
  return (
    <main>
      <h1>Karibu BetGeniusTZ!</h1>
      <p>Hii ni mwanzo wa App yako ya Kisasa kwa Next.js 14.</p>
    </main>
  );
}
