export default function Home() {
  return <h1>Karibu BetGeniusTZ 🌍</h1>;
}
