# BetGeniusTZ

Tovuti ya kusaidia watumiaji kupata betting tips bora kwa kutumia odds, takwimu na mbinu za kisasa.

## Kuanza (Development mode)
```bash
npm install
npm run dev
```

## Deployment
Unaweza ku-deploy kwenye Vercel bure.
