export default function HomePage() {
  return (
    <main className="p-4 text-center">
      <h1 className="text-3xl font-bold mb-4">Karibu BetGeniusTZ</h1>
      <p className="text-lg">Pata dondoo bora za mikeka na betting tips kila siku!</p>
    </main>
  )
}